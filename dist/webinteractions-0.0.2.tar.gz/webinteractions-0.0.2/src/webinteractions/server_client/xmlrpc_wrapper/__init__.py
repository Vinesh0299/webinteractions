"""Module provides functions that creates an xml-rpc server
    and client"""

from .client import *
from .server import *
