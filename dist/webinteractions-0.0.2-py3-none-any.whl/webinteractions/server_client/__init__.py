"""Provides functions that allows the user to create a server with
    with a simple function call."""

from . import xmlrpc_wrapper
from . import tcp_socket_server
from . import udp_socket_server
