"""Allowing user remotely access or control the program
    over the network"""

from .cgi_script import *
